from django.apps import AppConfig


class IngredientsConfig(AppConfig):
    name = "cookbook.ingredients"
    label = "ingredients"
    verbose_name = "Ingredients"
